const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { evaluateMath, localReply, tryCalculation, tryConversion } = require('../public/assistant');
const { createServer } = require('../server');
const root = path.join(__dirname, '..');

test('safe math evaluator respects precedence, parentheses, percentages, and exponents', () => {
  assert.equal(evaluateMath('2 + 3 * 4'), 14);
  assert.equal(evaluateMath('(2 + 3) * 4'), 20);
  assert.equal(evaluateMath('2^3^2'), 512);
  assert.equal(evaluateMath('50% * 80'), 40);
  assert.throws(() => evaluateMath('1 / 0'), /Division by zero/);
  assert.throws(() => evaluateMath('process.exit()'));
});

test('chat calculation answers include a readable result', () => {
  assert.match(tryCalculation('What is 18% of 245?'), /44\.1/);
  assert.match(tryCalculation('calculate (12 + 8) / 4'), /5/);
  assert.equal(tryCalculation('tell me about 2 apples'), null);
});

test('common unit conversions return correct values and mismatched units are declined', () => {
  assert.match(tryConversion('convert 100 celsius to fahrenheit'), /212 °F/);
  assert.match(tryConversion('5 km to miles'), /3\.10685596 mi/);
  assert.match(tryConversion('convert 1 kg to lb'), /2\.20462262 lb/);
  assert.equal(tryConversion('convert 2 liters to kilograms'), null);
});

test('keyless assistant works in-browser and is transparent about its limits', () => {
  assert.match(localReply([{ role: 'user', content: 'Hello!' }]), /I’m Veylo/);
  assert.match(localReply([{ role: 'user', content: 'What can you do?' }]), /no API keys/);
  assert.match(localReply([{ role: 'user', content: 'What is 9 * 8?' }]), /72/);

  const app = fs.readFileSync(path.join(root, 'public/app.js'), 'utf8');
  const html = fs.readFileSync(path.join(root, 'public/index.html'), 'utf8');
  assert.doesNotMatch(app, /\bfetch\s*\(/);
  assert.match(html, /<script src="\.\/assistant\.js" defer><\/script>/);
  assert.match(html, /<script src="\.\/app\.js" defer><\/script>/);
});

test('assistant bundle attaches its keyless engine to the browser window', () => {
  const source = fs.readFileSync(path.join(root, 'public/assistant.js'), 'utf8');
  const browserWindow = {};
  vm.runInNewContext(source, { window: browserWindow });
  assert.equal(typeof browserWindow.VeyloAssistant.localReply, 'function');
  assert.match(browserWindow.VeyloAssistant.localReply([{ role: 'user', content: 'What is 20 + 22?' }]), /42/);
});

test('project contains Cloudflare Pages configuration with a self-contained public directory', () => {
  const config = fs.readFileSync(path.join(root, 'wrangler.toml'), 'utf8');
  assert.match(config, /pages_build_output_dir\s*=\s*["']\.\/public["']/);
  for (const file of ['index.html', 'styles.css', 'app.js', 'assistant.js', '_headers']) {
    assert.ok(fs.existsSync(path.join(root, 'public', file)), `${file} exists in public/`);
  }
});

test('static server serves the keyless site and does not expose a chat API', async (t) => {
  const server = createServer();
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  t.after(async () => {
    await new Promise((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
  });

  const base = `http://127.0.0.1:${server.address().port}`;
  const page = await fetch(base);
  assert.equal(page.status, 200);
  assert.match(page.headers.get('content-type'), /text\/html/);
  assert.match(await page.text(), /Veylo — AI chat/);

  const assistant = await fetch(`${base}/assistant.js`);
  assert.equal(assistant.status, 200);
  assert.match(await assistant.text(), /window\.VeyloAssistant/);

  const app = await fetch(`${base}/app.js`);
  assert.equal(app.status, 200);
  assert.match(await app.text(), /localReply\(messages, context\)/);

  const api = await fetch(`${base}/api/chat`);
  assert.equal(api.status, 404);
});

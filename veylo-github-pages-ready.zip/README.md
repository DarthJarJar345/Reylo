# Veylo — keyless chat website

Veylo is a responsive chat website with an original, lightweight assistant that runs entirely in the visitor's browser. It has **no AI API keys, no remote model calls, and no chat backend**. Chat history is stored in browser storage when available.

The built-in assistant handles arithmetic, common unit conversions, and guided brainstorming, writing, planning, and explanations. It is a small rule-based assistant—not a general-purpose large language model—and it cannot browse current facts.

## Run locally

Requires Node.js 18 or newer. There are no npm dependencies.

```bash
npm start
```

Open [http://localhost:4173](http://localhost:4173). The tiny Node server only serves static files; the chat itself works in the browser.

## Publish on GitHub Pages

The repository includes a GitHub Actions workflow that publishes the contents of `public/`. I can't push to a GitHub account from this workspace unless it is authorized, so create a repository in your account and upload/push this project first.

1. Create a GitHub repository and push the project files, including `.github/workflows/pages.yml`.
2. In the repository, open **Settings → Pages** and set **Build and deployment → Source** to **GitHub Actions**.
3. Push to the `main` branch (or run **Actions → Deploy Veylo to GitHub Pages → Run workflow**).
4. GitHub will show the public URL in the Pages settings; it is usually `https://<username>.github.io/<repository>/`.

The site uses relative asset paths and works from a repository subpath. Do not put account passwords or access tokens in the repository. Veylo itself needs no API key.

## Deploy to Cloudflare Pages

A Cloudflare account is required for a permanent public site. No AI API key is needed by Veylo. Wrangler uses Cloudflare's browser login flow.

```bash
npx wrangler login
npx wrangler pages project create veylo-chat --production-branch=main
npx wrangler pages deploy ./public --project-name=veylo-chat
```

Cloudflare will print the deployed `*.pages.dev` URL. The `public/` folder is a self-contained static site, so Pages needs no backend or environment secrets.

## Verify

```bash
npm test
```

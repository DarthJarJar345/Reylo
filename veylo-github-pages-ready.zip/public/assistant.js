const SYSTEM_PROMPT = `You are Veylo, a clear, thoughtful AI assistant. Be useful, accurate, and honest about uncertainty. Do not claim to be infallible or superior to other systems. Ask a focused follow-up question when needed, otherwise make reasonable assumptions and state them. Use concise structure and show calculations when useful. If the user asks for current information and no browsing tool is available, say that you cannot verify live updates.`;

function tokenizeMath(input) {
  const tokens = [];
  let i = 0;
  while (i < input.length) {
    const char = input[i];
    if (/\s/.test(char)) {
      i += 1;
      continue;
    }
    const number = input.slice(i).match(/^(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?/i);
    if (number) {
      tokens.push({ type: 'number', value: Number(number[0]) });
      i += number[0].length;
      continue;
    }
    if ('+-*/^()%'.includes(char)) {
      tokens.push({ type: char, value: char });
      i += 1;
      continue;
    }
    throw new Error('Unsupported character in calculation.');
  }
  return tokens;
}

function evaluateMath(input) {
  const tokens = tokenizeMath(input);
  let cursor = 0;
  const peek = () => tokens[cursor];
  const take = (type) => {
    if (!peek() || peek().type !== type) throw new Error(`Expected ${type}.`);
    return tokens[cursor++];
  };

  function expression() {
    let value = term();
    while (peek() && (peek().type === '+' || peek().type === '-')) {
      const operator = tokens[cursor++].type;
      const right = term();
      value = operator === '+' ? value + right : value - right;
    }
    return value;
  }

  function term() {
    let value = unary();
    while (peek() && (peek().type === '*' || peek().type === '/')) {
      const operator = tokens[cursor++].type;
      const right = unary();
      if (operator === '/' && right === 0) throw new Error('Division by zero.');
      value = operator === '*' ? value * right : value / right;
    }
    return value;
  }

  function unary() {
    if (peek() && peek().type === '+') {
      cursor += 1;
      return unary();
    }
    if (peek() && peek().type === '-') {
      cursor += 1;
      return -unary();
    }
    return power();
  }

  function power() {
    let value = primary();
    if (peek() && peek().type === '^') {
      cursor += 1;
      value = value ** unary();
    }
    return value;
  }

  function primary() {
    let value;
    if (peek() && peek().type === 'number') {
      value = take('number').value;
    } else if (peek() && peek().type === '(') {
      take('(');
      value = expression();
      take(')');
    } else {
      throw new Error('Expected a number or parenthesis.');
    }
    while (peek() && peek().type === '%') {
      cursor += 1;
      value /= 100;
    }
    return value;
  }

  if (!tokens.length) throw new Error('No calculation found.');
  const result = expression();
  if (cursor !== tokens.length) throw new Error('Unexpected token in calculation.');
  if (!Number.isFinite(result)) throw new Error('Result is outside the supported range.');
  return result;
}

function formatNumber(value) {
  if (Number.isInteger(value)) return value.toLocaleString('en-US');
  return Number(value.toPrecision(10)).toLocaleString('en-US', { maximumFractionDigits: 8 });
}

function tryCalculation(text) {
  const percentOf = text.match(/(-?\d+(?:\.\d+)?)\s*%\s*(?:of|from)\s*(-?\d+(?:\.\d+)?)/i);
  if (percentOf) {
    const answer = (Number(percentOf[1]) / 100) * Number(percentOf[2]);
    return `**${percentOf[1]}% of ${percentOf[2]} is ${formatNumber(answer)}.**\n\nCalculation: ${percentOf[1]} ÷ 100 × ${percentOf[2]} = ${formatNumber(answer)}.`;
  }

  const stripped = text
    .trim()
    .replace(/^(?:(?:what is|what's|calculate|compute|solve|evaluate)\s+)/i, '')
    .replace(/[?=]+$/g, '')
    .trim();
  if (!/\d/.test(stripped) || !/[+*/^()%\-]/.test(stripped)) return null;
  if (!/^[\d\s()+*/^%.\-]+$/.test(stripped)) return null;
  try {
    const result = evaluateMath(stripped);
    return `**${formatNumber(result)}**\n\nCalculation: \`${stripped}\` = ${formatNumber(result)}.`;
  } catch (error) {
    if (error.message === 'Division by zero.') return 'That calculation divides by zero, so it has no finite result.';
    return null;
  }
}

const UNIT_ALIASES = {
  c: 'c', celsius: 'c', '°c': 'c',
  f: 'f', fahrenheit: 'f', '°f': 'f',
  km: 'km', kilometer: 'km', kilometers: 'km', kilometre: 'km', kilometres: 'km',
  mi: 'mi', mile: 'mi', miles: 'mi',
  m: 'm', meter: 'm', meters: 'm', metre: 'm', metres: 'm',
  cm: 'cm', centimeter: 'cm', centimeters: 'cm', centimetre: 'cm', centimetres: 'cm',
  ft: 'ft', foot: 'ft', feet: 'ft',
  kg: 'kg', kilogram: 'kg', kilograms: 'kg',
  lb: 'lb', lbs: 'lb', pound: 'lb', pounds: 'lb',
  g: 'g', gram: 'g', grams: 'g',
  oz: 'oz', ounce: 'oz', ounces: 'oz',
  l: 'l', liter: 'l', liters: 'l', litre: 'l', litres: 'l',
  ml: 'ml', milliliter: 'ml', milliliters: 'ml', millilitre: 'ml', millilitres: 'ml'
};

function tryConversion(text) {
  const match = text.match(/(?:convert\s+)?(-?\d+(?:\.\d+)?)\s*(°?\s*[a-z]+|°[cf])\s+(?:to|into|in)\s+(°?\s*[a-z]+|°[cf])/i);
  if (!match) return null;
  const amount = Number(match[1]);
  const fromRaw = match[2].replace(/\s+/g, '').toLowerCase();
  const toRaw = match[3].replace(/\s+/g, '').toLowerCase();
  const from = UNIT_ALIASES[fromRaw];
  const to = UNIT_ALIASES[toRaw];
  if (!from || !to) return null;

  let converted;
  let unitName = toRaw;
  if (from === to) converted = amount;
  else if (from === 'c' && to === 'f') { converted = amount * 9 / 5 + 32; unitName = '°F'; }
  else if (from === 'f' && to === 'c') { converted = (amount - 32) * 5 / 9; unitName = '°C'; }
  else {
    const toBase = {
      km: 1000, mi: 1609.344, m: 1, cm: 0.01, ft: 0.3048,
      kg: 1000, lb: 453.59237, g: 1, oz: 28.349523125,
      l: 1000, ml: 1
    };
    const family = (unit) => ['km', 'mi', 'm', 'cm', 'ft'].includes(unit) ? 'length'
      : ['kg', 'lb', 'g', 'oz'].includes(unit) ? 'mass'
      : ['l', 'ml'].includes(unit) ? 'volume' : null;
    if (!toBase[from] || !toBase[to] || family(from) !== family(to)) return null;
    converted = amount * toBase[from] / toBase[to];
  }
  return `**${formatNumber(amount)} ${match[2]} = ${formatNumber(converted)} ${unitName}.**`;
}

function getClientClock(context) {
  if (!context || typeof context.now !== 'string') return null;
  const date = new Date(context.now);
  if (Number.isNaN(date.getTime())) return null;
  const zone = typeof context.timeZone === 'string' ? context.timeZone.slice(0, 80) : 'your local time zone';
  return { date, zone };
}

function localReply(messages, context = {}) {
  const lastUser = [...messages].reverse().find((message) => message.role === 'user');
  const text = (lastUser && lastUser.content || '').trim();
  const lower = text.toLowerCase();
  if (!text) return 'Send me a question or task, and I’ll take a first pass.';

  const calculation = tryCalculation(text);
  if (calculation) return calculation;
  const conversion = tryConversion(text);
  if (conversion) return conversion;

  if (/\b(?:time|date|today|what day)\b/.test(lower) && /\b(?:now|current|today|date|time|day)\b/.test(lower)) {
    const clock = getClientClock(context);
    if (clock) {
      const asksTime = /\b(?:time|right now|current time)\b/.test(lower);
      const value = asksTime
        ? clock.date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', timeZone: clock.zone })
        : clock.date.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', timeZone: clock.zone });
      return `It’s **${value}** in **${clock.zone}**.`;
    }
  }

  if (/^(?:hi|hello|hey|good morning|good afternoon|good evening|howdy)[!. ]*$/i.test(text)) {
    return 'Hi! I’m Veylo, a custom-built assistant. Tell me what you’re trying to do—solve a problem, plan something, draft a message, or explore an idea—and I’ll help you work through it.';
  }

  if (/\b(?:who are you|what are you|what can you do|help|how do you work)\b/i.test(text)) {
    return `I’m **Veylo**, a custom-built, keyless chat assistant. I can do arithmetic, common unit conversions, and structured help with writing, planning, brainstorming, and explanations.\n\nMy small rule-based engine runs entirely in your browser—no API keys, external model calls, or message uploads. I’m not a frontier language model, and I can make mistakes. I also don’t have live web access.`;
  }

  if (/\b(?:summari[sz]e|tl;dr|give me the gist)\b/i.test(text)) {
    const supplied = text.replace(/^(?:please\s+)?(?:summari[sz]e|tl;dr|give me the gist)(?:\s+this|\s+the following)?\s*[:\-]?\s*/i, '').trim();
    if (!supplied || supplied.length < 40) {
      return 'Sure—paste the passage you want summarized after “Summarize:”. I can then pull out the main point, key details, and any open questions.';
    }
    const sentences = supplied.match(/[^.!?]+[.!?]?/g) || [supplied];
    const words = supplied.split(/\s+/);
    const first = sentences.slice(0, 2).join(' ').trim();
    const compact = words.length > 85 ? `${words.slice(0, 85).join(' ')}…` : supplied;
    return `**Short summary:** ${compact}\n\n**Opening point:** ${first}\n\nThis built-in summary is a lightweight text shortcut, not a deep semantic review; double-check nuanced conclusions.`;
  }

  if (/\b(?:brainstorm|ideas|idea|creative options)\b/i.test(text)) {
    const subject = text.replace(/\b(?:please\s+)?(?:brainstorm|give me|suggest|list)?\s*(?:some\s+)?(?:ideas|idea|creative options)\s*(?:for|about|on)?\s*/i, '').trim() || 'your topic';
    return `Here are a few useful angles for **${subject}**:\n\n- **Make it smaller:** design a quick version you can test in one afternoon.\n- **Make it personal:** tie it to a specific audience, place, or everyday frustration.\n- **Make it shareable:** turn the result into a checklist, template, or short demo.\n- **Try the opposite:** challenge the default assumption and see what a contrarian version looks like.\n- **Combine two things:** pair your topic with a neighboring interest or tool.\n\nIf you share the audience and constraints, I can make the ideas much more specific.`;
  }

  if (/\b(?:plan|planning|roadmap|schedule|steps to)\b/i.test(text)) {
    const subject = text.replace(/\b(?:help me\s+)?(?:plan|planning|make a plan|create a roadmap|roadmap for|schedule|steps to)\s*/i, '').trim() || 'your goal';
    return `A practical starting plan for **${subject}**:\n\n1. **Define the finish line.** Write one measurable outcome and a target date.\n2. **List constraints.** Note available time, budget, people, and anything that cannot change.\n3. **Break it into milestones.** Choose three to five checkpoints, each with a concrete deliverable.\n4. **Pick the next 30-minute action.** Make the first step small enough to start today.\n5. **Review weekly.** Keep what is working, revise what is not, and surface blockers early.\n\nTell me your deadline and constraints and I’ll turn this into a tailored schedule.`;
  }

  if (/\b(?:write|draft|compose|rewrite|polish|email|message|cover letter|caption)\b/i.test(text)) {
    const topic = text.replace(/\b(?:please\s+)?(?:write|draft|compose|rewrite|polish)\s*/i, '').trim();
    if (!topic || topic.length < 5) {
      return 'Absolutely. What are we writing, who will read it, and what tone should it have? You can also paste a rough draft and say “make it clearer” or “make it warmer.”';
    }
    return `I can help draft **${topic}**. To make it sound right, tell me the audience, desired tone, and any details that must be included. If you want a quick first draft now, reply with just “friendly,” “formal,” or “concise.”`;
  }

  if (/\b(?:explain|teach me|what does .* mean|how does .* work)\b/i.test(text)) {
    const topic = text.replace(/\b(?:can you\s+)?(?:explain|teach me(?: about)?|how does|what does)\s*/i, '').replace(/\s+mean\??$/i, '').replace(/\s+work\??$/i, '').trim();
    return `I can walk through **${topic || 'that concept'}** step by step. The clearest explanation depends on the context—what do you already know about it, and would you prefer a simple analogy or a more technical explanation?\n\nThis keyless version has no broad reference library, so I’d rather ask than invent specifics. Share a source or more context and I can help reason through it.`;
  }

  if (/\b(?:code|program|javascript|python|html|css|bug|error|function|script)\b/i.test(text)) {
    return `I can help with the code. Please share the language, what you expected to happen, what actually happened, and the smallest relevant code snippet. I’ll look for a concrete fix.\n\nThis built-in mode doesn’t run code or have a full programming model connected, so please test any suggested changes before using them.`;
  }

  if (/\b(?:current|latest|today|right now|breaking|weather|stock price|news)\b/i.test(lower)) {
    return 'I don’t have live web access, so I can’t verify current information. Share a source or the details you have, and I can help analyze them.';
  }

  if (/\b(?:thank you|thanks|thx)\b/i.test(lower)) {
    return 'You’re welcome! If you want, send the next step or any details you’d like me to work with.';
  }

  return `I’ve got your request: **${text.length > 180 ? `${text.slice(0, 177)}…` : text}**\n\nI’m a keyless, browser-based assistant. I can handle arithmetic, common conversions, and structured brainstorming, planning, and writing prompts. I don’t have a broad language model or live web access, so I don’t want to invent an answer outside those strengths. Share more context or a source and I’ll work with it.`;
}

const VeyloAssistant = { SYSTEM_PROMPT, evaluateMath, localReply, tryCalculation, tryConversion };

if (typeof module !== 'undefined' && module.exports) module.exports = VeyloAssistant;
if (typeof window !== 'undefined') window.VeyloAssistant = VeyloAssistant;

(() => {
  const STORAGE_KEY = 'veylo.conversations.v1';
  const ACTIVE_KEY = 'veylo.activeConversation.v1';
  const LEGACY_STORAGE_KEY = 'astra.conversations.v1';
  const LEGACY_ACTIVE_KEY = 'astra.activeConversation.v1';
  const MAX_CONVERSATIONS = 30;
  const $ = (selector) => document.querySelector(selector);
  const $$ = (selector) => [...document.querySelectorAll(selector)];

  const els = {
    sidebar: $('#sidebar'),
    conversationList: $('#conversationList'),
    historyCount: $('#historyCount'),
    newChatButton: $('#newChatButton'),
    searchToggle: $('#searchToggle'),
    searchWrap: $('#searchWrap'),
    searchInput: $('#searchInput'),
    activeTitle: $('#activeTitle'),
    welcomeScreen: $('#welcomeScreen'),
    suggestionGrid: $('#suggestionGrid'),
    messageFeed: $('#messageFeed'),
    chatStage: $('#chatStage'),
    chatForm: $('#chatForm'),
    messageInput: $('#messageInput'),
    sendButton: $('#sendButton'),
    modelStatus: $('#modelStatus'),
    modelStatusText: $('#modelStatusText'),
    sidebarMode: $('#sidebarMode'),
    sidebarStatusDetail: $('#sidebarStatusDetail'),
    readyDot: $('#readyDot'),
    settingsModal: $('#settingsModal'),
    settingsModeTitle: $('#settingsModeTitle'),
    settingsModeDescription: $('#settingsModeDescription'),
    settingsPill: $('#settingsPill'),
    toast: $('#toast'),
    mobileScrim: $('#mobileScrim')
  };

  let conversations = loadConversations();
  let activeId = storageGet(ACTIVE_KEY) || storageGet(LEGACY_ACTIVE_KEY) || '';
  let pendingRequest = null;
  let toastTimer = null;
  let storageWarned = false;

  function storageGet(key) {
    try { return localStorage.getItem(key); } catch { return null; }
  }

  function makeId() {
    if (window.crypto && typeof window.crypto.randomUUID === 'function') return window.crypto.randomUUID();
    return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
  }

  function loadConversations() {
    try {
      const saved = JSON.parse(storageGet(STORAGE_KEY) || storageGet(LEGACY_STORAGE_KEY) || '[]');
      if (!Array.isArray(saved)) return [];
      return saved
        .filter((item) => item && typeof item.id === 'string' && Array.isArray(item.messages))
        .map((item) => ({
          id: item.id,
          title: typeof item.title === 'string' ? item.title : 'Conversation',
          updatedAt: Number(item.updatedAt) || Date.now(),
          messages: item.messages.slice(0, 100).filter((message) => message && ['user', 'assistant'].includes(message.role) && typeof message.content === 'string')
        }))
        .sort((a, b) => b.updatedAt - a.updatedAt)
        .slice(0, MAX_CONVERSATIONS);
    } catch {
      return [];
    }
  }

  function saveState() {
    try {
      conversations.sort((a, b) => b.updatedAt - a.updatedAt);
      conversations = conversations.slice(0, MAX_CONVERSATIONS);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(conversations));
      if (activeId) localStorage.setItem(ACTIVE_KEY, activeId);
      else localStorage.removeItem(ACTIVE_KEY);
      storageWarned = false;
    } catch {
      if (!storageWarned) showToast('Browser storage is unavailable; chats will last until you close this tab.');
      storageWarned = true;
    }
  }

  function activeConversation() {
    return conversations.find((conversation) => conversation.id === activeId) || null;
  }

  function makeConversation() {
    const conversation = { id: makeId(), title: 'New conversation', updatedAt: Date.now(), messages: [] };
    conversations.unshift(conversation);
    activeId = conversation.id;
    saveState();
    return conversation;
  }

  function titleFromMessage(content) {
    const plain = content.replace(/\s+/g, ' ').trim();
    return plain.length > 34 ? `${plain.slice(0, 33).trimEnd()}…` : plain || 'New conversation';
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, (character) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    })[character]);
  }

  function renderMarkdown(markdown) {
    const codeBlocks = [];
    let text = String(markdown || '').replace(/\r\n?/g, '\n');
    text = text.replace(/```([^\n`]*)\n?([\s\S]*?)```/g, (_match, language, code) => {
      const label = String(language || '').trim();
      const html = `<pre${label ? ` data-language="${escapeHtml(label)}"` : ''}><code>${escapeHtml(code.replace(/\n$/, ''))}</code></pre>`;
      const index = codeBlocks.push(html) - 1;
      return `\u0000VEYLOCODE${index}\u0000`;
    });

    function inline(line) {
      const inlineCodes = [];
      let result = line.replace(/`([^`]+)`/g, (_match, code) => {
        const index = inlineCodes.push(`<code>${escapeHtml(code)}</code>`) - 1;
        return `\u0001VEYLOINLINE${index}\u0001`;
      });
      result = escapeHtml(result);
      result = result.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
      result = result.replace(/(^|[^*])\*([^*\n]+)\*(?!\*)/g, '$1<em>$2</em>');
      result = result.replace(/\u0001VEYLOINLINE(\d+)\u0001/g, (_match, index) => inlineCodes[Number(index)] || '');
      return result;
    }

    const lines = text.split('\n');
    const output = [];
    let paragraph = [];
    let listType = '';

    const flushParagraph = () => {
      if (paragraph.length) {
        output.push(`<p>${paragraph.map(inline).join('<br>')}</p>`);
        paragraph = [];
      }
    };
    const closeList = () => {
      if (listType) {
        output.push(`</${listType}>`);
        listType = '';
      }
    };

    for (const line of lines) {
      const trimmed = line.trim();
      const blockToken = trimmed.match(/^\u0000VEYLOCODE(\d+)\u0000$/);
      if (blockToken) {
        flushParagraph();
        closeList();
        output.push(`\u0000VEYLOCODE${blockToken[1]}\u0000`);
        continue;
      }
      if (!trimmed) {
        flushParagraph();
        closeList();
        continue;
      }
      const heading = trimmed.match(/^(#{1,3})\s+(.+)$/);
      if (heading) {
        flushParagraph();
        closeList();
        const level = heading[1].length;
        output.push(`<h${level}>${inline(heading[2])}</h${level}>`);
        continue;
      }
      const quote = trimmed.match(/^>\s?(.*)$/);
      if (quote) {
        flushParagraph();
        closeList();
        output.push(`<blockquote>${inline(quote[1])}</blockquote>`);
        continue;
      }
      const unordered = trimmed.match(/^[-*]\s+(.+)$/);
      const ordered = trimmed.match(/^\d+[.)]\s+(.+)$/);
      if (unordered || ordered) {
        flushParagraph();
        const nextType = unordered ? 'ul' : 'ol';
        if (listType && listType !== nextType) closeList();
        if (!listType) {
          listType = nextType;
          output.push(`<${listType}>`);
        }
        output.push(`<li>${inline((unordered || ordered)[1])}</li>`);
        continue;
      }
      closeList();
      paragraph.push(line);
    }
    flushParagraph();
    closeList();
    return output.join('').replace(/\u0000VEYLOCODE(\d+)\u0000/g, (_match, index) => codeBlocks[Number(index)] || '');
  }

  function sparkleIcon() {
    return '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m12 3 2.15 6.85L21 12l-6.85 2.15L12 21l-2.15-6.85L3 12l6.85-2.15L12 3Z" fill="currentColor"/></svg>';
  }

  function renderMessage(message, index) {
    const isUser = message.role === 'user';
    const modeLabel = !isUser && message.mode === 'model' ? 'Connected model' : (!isUser && message.mode === 'error' ? 'Notice' : (!isUser ? 'Built-in response' : ''));
    const content = isUser ? escapeHtml(message.content).replace(/\n/g, '<br>') : renderMarkdown(message.content);
    const tools = !isUser && message.mode !== 'error'
      ? `<div class="message-actions"><button class="message-action" type="button" data-action="copy" data-index="${index}" aria-label="Copy response"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/></svg><span>Copy</span></button></div>`
      : '';
    return `<article class="message-row ${isUser ? 'user' : 'assistant'}" data-index="${index}">
      ${isUser ? '' : `<div class="message-avatar" aria-hidden="true">${sparkleIcon()}</div>`}
      <div class="message-column">
        ${isUser ? '' : `<div class="message-header">Veylo <span class="message-mode">${modeLabel}</span></div>`}
        <div class="message-bubble">${content}</div>${tools}
      </div>
    </article>`;
  }

  function renderConversation() {
    const conversation = activeConversation();
    const hasMessages = Boolean(conversation && conversation.messages.length);
    els.welcomeScreen.hidden = hasMessages;
    els.messageFeed.hidden = !hasMessages;
    els.activeTitle.textContent = hasMessages ? conversation.title.toLocaleUpperCase() : 'NEW CONVERSATION';
    if (hasMessages) {
      els.messageFeed.innerHTML = conversation.messages.map(renderMessage).join('');
      if (pendingRequest && pendingRequest.conversationId === conversation.id) {
        els.messageFeed.insertAdjacentHTML('beforeend', `<article class="message-row assistant"><div class="message-avatar" aria-hidden="true">${sparkleIcon()}</div><div class="message-column"><div class="message-header">Veylo <span class="message-mode">Thinking</span></div><div class="typing-indicator" aria-label="Veylo is thinking"><span></span><span></span><span></span></div></div></article>`);
      }
      requestAnimationFrame(() => { els.chatStage.scrollTop = els.chatStage.scrollHeight; });
    } else {
      els.messageFeed.innerHTML = '';
    }
    renderConversationList();
  }

  function renderConversationList() {
    const query = els.searchInput.value.trim().toLocaleLowerCase();
    const recent = conversations.filter((conversation) => conversation.messages.length);
    const filtered = query ? recent.filter((conversation) => (
      conversation.title.toLocaleLowerCase().includes(query)
      || conversation.messages.some((message) => message.content.toLocaleLowerCase().includes(query))
    )) : recent;
    els.historyCount.textContent = recent.length ? String(recent.length) : '';
    if (!filtered.length) {
      els.conversationList.innerHTML = `<div class="conversation-empty">${query ? 'No matching conversations.' : 'Your conversations will appear here.'}</div>`;
      return;
    }
    els.conversationList.innerHTML = filtered.map((conversation) => `
      <div class="conversation-item ${conversation.id === activeId ? 'active' : ''}" role="button" tabindex="0" data-conversation-id="${escapeHtml(conversation.id)}" aria-label="Open ${escapeHtml(conversation.title)}">
        <svg class="conversation-star" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m12 3 2.15 6.85L21 12l-6.85 2.15L12 21l-2.15-6.85L3 12l6.85-2.15L12 3Z" stroke="currentColor" stroke-width="1.3"/></svg>
        <span class="conversation-title">${escapeHtml(conversation.title)}</span>
        <button class="conversation-delete" type="button" data-delete-id="${escapeHtml(conversation.id)}" aria-label="Delete ${escapeHtml(conversation.title)}"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M10 11v6m4-6v6M6 7l1 14h10l1-14M9 7V4h6v3"/></svg></button>
      </div>`).join('');
  }

  function updateComposer() {
    const hasText = Boolean(els.messageInput.value.trim());
    const loading = Boolean(pendingRequest);
    els.sendButton.classList.toggle('loading', loading);
    els.sendButton.setAttribute('aria-label', loading ? 'Stop response' : 'Send message');
    els.sendButton.disabled = loading ? false : !hasText;
    els.messageInput.disabled = loading;
  }

  function updateConnectionUI() {
    els.modelStatusText.textContent = 'KEYLESS MODE';
    els.modelStatus.classList.remove('connected');
    els.sidebarMode.textContent = 'Built-in assistant';
    els.sidebarStatusDetail.textContent = 'Runs in your browser';
    els.readyDot.style.background = '';
    els.readyDot.style.boxShadow = '';
    els.settingsModeTitle.textContent = 'Built-in assistant';
    els.settingsModeDescription.textContent = 'Runs locally in your browser. No API key or remote model.';
    els.settingsPill.textContent = 'KEYLESS';
  }

  function showToast(message) {
    els.toast.textContent = message;
    els.toast.classList.add('visible');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => els.toast.classList.remove('visible'), 2300);
  }

  function cancelPending(keepNotice) {
    if (!pendingRequest) return;
    const request = pendingRequest;
    request.controller.abort();
    pendingRequest = null;
    if (keepNotice) {
      const conversation = conversations.find((item) => item.id === request.conversationId);
      if (conversation) {
        conversation.messages.push({ role: 'assistant', content: 'Response stopped. You can continue whenever you’re ready.', mode: 'local', createdAt: Date.now() });
        conversation.updatedAt = Date.now();
        saveState();
      }
    }
    updateComposer();
    if (activeId === request.conversationId) renderConversation();
  }

  async function sendMessage(rawText) {
    if (pendingRequest) {
      cancelPending(true);
      return;
    }
    const content = String(rawText || '').trim();
    if (!content) return;
    let conversation = activeConversation();
    if (!conversation) conversation = makeConversation();
    conversation.messages.push({ role: 'user', content, createdAt: Date.now() });
    if (conversation.messages.filter((message) => message.role === 'user').length === 1) conversation.title = titleFromMessage(content);
    conversation.updatedAt = Date.now();
    activeId = conversation.id;
    saveState();
    els.messageInput.value = '';
    resizeInput();

    const request = { id: makeId(), conversationId: conversation.id, controller: new AbortController() };
    pendingRequest = request;
    updateComposer();
    renderConversation();

    const messages = conversation.messages
      .filter((message) => ['user', 'assistant'].includes(message.role))
      .slice(-24)
      .map((message) => ({ role: message.role, content: message.content }));
    const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
    const context = { now: new Date().toISOString(), timeZone };

    try {
      await new Promise((resolve) => window.setTimeout(resolve, 260));
      if (pendingRequest !== request) return;
      if (!window.VeyloAssistant || typeof window.VeyloAssistant.localReply !== 'function') {
        throw new Error('The built-in assistant script did not load. Refresh the page and try again.');
      }
      const result = window.VeyloAssistant.localReply(messages, context);
      conversation.messages.push({ role: 'assistant', content: result, mode: 'local', createdAt: Date.now() });
      conversation.updatedAt = Date.now();
    } catch (error) {
      if (pendingRequest !== request || error.name === 'AbortError') return;
      const friendly = error.message || 'Something went wrong while generating a response.';
      conversation.messages.push({ role: 'assistant', content: `I couldn’t complete that request.\n\n${friendly}`, mode: 'error', createdAt: Date.now() });
      conversation.updatedAt = Date.now();
      showToast('The response did not complete.');
    } finally {
      if (pendingRequest === request) {
        pendingRequest = null;
        saveState();
        updateComposer();
        if (activeId === request.conversationId) renderConversation();
      }
    }
  }

  function resizeInput() {
    els.messageInput.style.height = 'auto';
    els.messageInput.style.height = `${Math.min(els.messageInput.scrollHeight, 180)}px`;
    updateComposer();
  }

  function openNewConversation() {
    cancelPending(false);
    makeConversation();
    renderConversation();
    els.messageInput.value = '';
    resizeInput();
    closeSidebar();
    els.messageInput.focus();
  }

  function openSidebar() {
    els.sidebar.classList.add('open');
    els.mobileScrim.hidden = false;
  }

  function closeSidebar() {
    els.sidebar.classList.remove('open');
    els.mobileScrim.hidden = true;
  }

  function openSettings() {
    els.settingsModal.hidden = false;
    $('#closeSettings').focus();
  }

  function closeSettings() {
    els.settingsModal.hidden = true;
    $('#topSettingsButton').focus();
  }

  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const temporary = document.createElement('textarea');
      temporary.value = text;
      temporary.style.position = 'fixed';
      temporary.style.opacity = '0';
      document.body.appendChild(temporary);
      temporary.select();
      document.execCommand('copy');
      temporary.remove();
    }
    showToast('Response copied to clipboard.');
  }

  els.chatForm.addEventListener('submit', (event) => {
    event.preventDefault();
    if (pendingRequest) {
      cancelPending(true);
      return;
    }
    const content = els.messageInput.value;
    if (!content.trim()) return;
    sendMessage(content);
  });

  els.messageInput.addEventListener('input', resizeInput);
  els.messageInput.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) {
      event.preventDefault();
      if (pendingRequest) cancelPending(true);
      else els.chatForm.requestSubmit();
    }
  });

  els.suggestionGrid.addEventListener('click', (event) => {
    const card = event.target.closest('[data-prompt]');
    if (card) sendMessage(card.dataset.prompt);
  });

  els.newChatButton.addEventListener('click', openNewConversation);
  $('#openSidebar').addEventListener('click', openSidebar);
  $('#closeSidebar').addEventListener('click', closeSidebar);
  els.mobileScrim.addEventListener('click', closeSidebar);

  els.searchToggle.addEventListener('click', () => {
    els.searchWrap.hidden = !els.searchWrap.hidden;
    if (!els.searchWrap.hidden) els.searchInput.focus();
    else {
      els.searchInput.value = '';
      renderConversationList();
    }
  });
  els.searchInput.addEventListener('input', renderConversationList);

  els.conversationList.addEventListener('click', (event) => {
    const deleteButton = event.target.closest('[data-delete-id]');
    if (deleteButton) {
      event.stopPropagation();
      const id = deleteButton.dataset.deleteId;
      const target = conversations.find((conversation) => conversation.id === id);
      if (!target) return;
      if (!window.confirm(`Delete “${target.title}”?`)) return;
      if (pendingRequest && pendingRequest.conversationId === id) cancelPending(false);
      conversations = conversations.filter((conversation) => conversation.id !== id);
      if (activeId === id) {
        activeId = conversations.find((conversation) => conversation.messages.length)?.id || '';
        if (!activeId) makeConversation();
      }
      saveState();
      renderConversation();
      return;
    }
    const item = event.target.closest('[data-conversation-id]');
    if (!item) return;
    const conversation = conversations.find((entry) => entry.id === item.dataset.conversationId);
    if (!conversation) return;
    cancelPending(false);
    activeId = conversation.id;
    saveState();
    renderConversation();
    closeSidebar();
  });
  els.conversationList.addEventListener('keydown', (event) => {
    if ((event.key === 'Enter' || event.key === ' ') && event.target.matches('[data-conversation-id]')) {
      event.preventDefault();
      event.target.click();
    }
  });

  els.messageFeed.addEventListener('click', (event) => {
    const copyButton = event.target.closest('[data-action="copy"]');
    if (!copyButton) return;
    const conversation = activeConversation();
    const message = conversation && conversation.messages[Number(copyButton.dataset.index)];
    if (message) copyText(message.content);
  });

  $('#settingsButton').addEventListener('click', openSettings);
  $('#topSettingsButton').addEventListener('click', openSettings);
  $('#closeSettings').addEventListener('click', closeSettings);
  els.settingsModal.addEventListener('click', (event) => {
    if (event.target === els.settingsModal) closeSettings();
  });
  document.addEventListener('keydown', (event) => {
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
      event.preventDefault();
      openNewConversation();
    }
    if (event.key === 'Escape') {
      if (!els.settingsModal.hidden) closeSettings();
      else if (els.sidebar.classList.contains('open')) closeSidebar();
    }
  });

  if (!conversations.some((conversation) => conversation.id === activeId)) activeId = '';
  if (!activeId) {
    const mostRecent = conversations.find((conversation) => conversation.messages.length);
    if (mostRecent) activeId = mostRecent.id;
    else makeConversation();
  }
  saveState();
  renderConversation();
  updateComposer();
  updateConnectionUI();
})();
